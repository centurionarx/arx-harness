/** Package-owned invariant companion. @module @arx-ai/arx-client-ui-settings-plugin-inventory/invariant */
import type { Context } from '@arx-ai/cordis';
/** Cordis companion plugin name. */
export declare const name = "client-ui-settings-plugin-inventory-invariant";
/** Service required before the companion can reserve package ownership. */
export declare const inject: string[];
/** Register this package's invariant companion. */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map