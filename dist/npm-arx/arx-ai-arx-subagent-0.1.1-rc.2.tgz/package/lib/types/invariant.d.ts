/** Package-owned subagent registry and lifecycle invariants. @module @arx-ai/arx-subagent/invariant */
import type { Context } from '@arx-ai/cordis';
/** Cordis companion plugin name. */
export declare const name = "subagent-invariant";
/** Service required before the companion can reserve package ownership. */
export declare const inject: string[];
/**
 * Register the subagent invariant companion.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns the installed registration's disposer after setup succeeds.
 */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map