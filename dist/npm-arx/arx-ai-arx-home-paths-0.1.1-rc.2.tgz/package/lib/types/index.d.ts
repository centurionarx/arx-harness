/**
 * Shared filesystem path helpers for arx Harness user data.
 *
 * @module @arx-ai/arx-home-paths
 */
/** Directory name for the default arx Harness home under the OS home. */
export declare const ARX_HOME_DIR_NAME = ".arx";
/** Stable user-facing display form for the default arx Harness home. */
export declare const DEFAULT_ARX_HOME_DISPLAY = "~/.arx";
/** Environment variable that overrides the default arx Harness home. */
export declare const ARX_HOME_ENV = "ARX_HOME";
/**
 * Give a native filesystem watcher one canonical spelling of a path, even
 * when its final components do not exist yet. The deepest existing ancestor
 * is resolved through {@link realpath}; when a suffix is missing, that
 * ancestor is also proved to be an enumerable directory before the suffix is
 * restored. This prevents Windows from treating a regular-file ancestor as
 * ordinary absence, and prevents short-name aliases from being mixed with
 * long paths emitted by the native watcher backend.
 * @param path - Watch target or root, resolved against the current directory.
 * @returns the target with its existing ancestor canonicalized.
 * @throws when ancestor traversal encounters an error other than absence, or
 * the existing ancestor of a missing suffix is not an enumerable directory.
 */
export declare function canonicalizeWatchPath(path: string): Promise<string>;
/**
 * Resolve the default arx Harness home using Node's platform path rules.
 * @returns the absolute default harness home path.
 */
export declare function defaultArxHome(): string;
/**
 * Expand supported tilde prefixes against the operating-system home.
 * @param path - configured path that may begin with `~`, `~/`, or `~\`.
 * @returns the expanded path, or the original value when no supported prefix is present.
 */
export declare function expandHomePath(path: string): string;
/**
 * Resolve the single-root arx Harness home.
 *
 * Precedence, highest first: an explicit configured path, `$ARX_HOME`, then
 * `~/.arx`. The harness keeps all user data under one root. An empty or
 * whitespace-only `$ARX_HOME` is treated as unset, so a blank override never
 * resolves the home to the current working directory.
 * @param configured - explicit harness-home override, which has highest precedence.
 * @param env - environment mapping used to read `ARX_HOME`.
 * @returns the normalized absolute harness home path.
 */
export declare function resolveArxHome(configured?: string, env?: Record<string, string | undefined>): string;
/**
 * Join path segments onto the resolved arx Harness home.
 * @param segments - path segments appended to the Harness home; an empty list returns the home itself.
 * @returns the normalized absolute joined path.
 */
export declare function arxHomePath(...segments: string[]): string;
/**
 * Describe a resolved harness home symbolically for user-facing display.
 *
 * It never returns an absolute machine path: the default home is labelled
 * `~/.arx`, and any configured home is labelled `$ARX_HOME`.
 * @param resolvedHome - the absolute path returned by {@link resolveArxHome}.
 * @returns `~/.arx` for the default home, otherwise `$ARX_HOME`.
 */
export declare function arxHomeDisplay(resolvedHome: string): string;
//# sourceMappingURL=index.d.ts.map