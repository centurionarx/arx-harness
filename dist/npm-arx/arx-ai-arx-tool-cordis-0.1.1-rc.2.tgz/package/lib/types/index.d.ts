/**
 * Model-facing Cordis runtime/package inspection, define, run, stop, and remove tools.
 * @module @arx-ai/arx-tool-cordis
 */
import type { Context } from '@arx-ai/cordis';
export declare const name = "tool-cordis";
export declare const inject: string[];
/** Register the Cordis tools and explicit `@pluginId` context injection. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map