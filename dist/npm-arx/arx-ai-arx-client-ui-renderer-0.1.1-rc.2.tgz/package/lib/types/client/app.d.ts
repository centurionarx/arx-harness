/**
 * Real-UI assembly closure. The whole layout tree hangs from the built-in
 * `root` slot, which is the only ctx-level slot render in the application.
 */
import type { ReactNode } from 'react';
import type { Context } from '@arx-ai/cordis';
/** Inputs available after the UI renderer's inject set activates. */
export interface AssemblyDeps {
    /** Client context carrying the slots and sessions services. */
    ctx: Context;
}
/**
 * Build the assembled application factory.
 * @param deps - Active UI-renderer dependencies.
 * @returns Factory producing the application React tree.
 */
export declare function buildRenderApp(deps: AssemblyDeps): () => ReactNode;
//# sourceMappingURL=app.d.ts.map