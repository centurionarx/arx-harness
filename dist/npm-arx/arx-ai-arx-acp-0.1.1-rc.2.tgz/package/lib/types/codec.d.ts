/**
 * Pure translation between the harness lifecycle and the automation-only ACP wire.
 * @module @arx-ai/arx-acp/codec
 */
import type { StopReason } from '@agentclientprotocol/sdk';
import type { TurnEndReason } from '@arx-ai/arx-session';
/**
 * Map a harness turn ending to ACP's terminal reason vocabulary.
 * @param reason - harness turn outcome.
 * @returns the closest legal ACP stop reason.
 */
export declare function turnEndToStopReason(reason: TurnEndReason): StopReason;
//# sourceMappingURL=codec.d.ts.map