/** Client-safe event declarations owned by the agent-preset domain. */
import type { SessionId } from '@arx-ai/arx-session/types';
declare module '@arx-ai/cordis' {
    interface Events {
        /**
         * One session committed a different agent preset to its durable log.
         * Consumers invalidate only state derived from that session's composition.
         * @mode emit
         * @param sessionId - the session whose composition changed.
         * @param agentPreset - the preset recorded by the committed selection.
         */
        'agent-preset/selected'(sessionId: SessionId, agentPreset: string): void;
    }
}
export {};
//# sourceMappingURL=types.d.ts.map