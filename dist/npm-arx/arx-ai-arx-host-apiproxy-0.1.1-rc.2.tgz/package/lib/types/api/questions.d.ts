/**
 * questions domain contract. The question requested frame is a
 * server-request whose rpcId is the question's stable logical id (minted when the host accepts
 * ask(); core user-questions has no request-level id); the answer is a client-response
 * echoing that rpcId, with no resource id in the payload (rpcId suffices).
 */
import type { AskUserQuestionAnswer } from '@arx-ai/arx-user-questions/types';
import type { SessionId } from '@arx-ai/arx-session/types';
/**
 * Question answer payload (the result.value slot of a client-response):
 * answers one ask() as a whole batch (core: one ask, many questions, one
 * answer — never split per question).
 */
export interface QuestionResponsePayload {
    sessionId: SessionId;
    answer: AskUserQuestionAnswer;
}
//# sourceMappingURL=questions.d.ts.map