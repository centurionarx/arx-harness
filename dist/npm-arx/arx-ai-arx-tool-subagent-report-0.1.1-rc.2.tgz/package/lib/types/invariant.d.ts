/**
 * Package-owned invariant companion for `@arx-ai/arx-tool-subagent-report`.
 * @module @arx-ai/arx-tool-subagent-report/invariant
 */
import type { Context } from '@arx-ai/cordis';
/** Cordis companion plugin name. */
export declare const name = "tool-subagent-report-invariant";
/** Service required before the companion can reserve package ownership. */
export declare const inject: string[];
/**
 * Register this package's invariant companion.
 * @param ctx - context carrying the invariant service.
 * @returns the registration disposer after setup succeeds.
 */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map