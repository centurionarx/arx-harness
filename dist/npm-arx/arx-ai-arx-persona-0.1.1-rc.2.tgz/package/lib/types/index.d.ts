/**
 * A per-agent persona as a composable row.
 *
 * `arx-system-prompt` owns the global persona as its own config, and registers
 * that section unconditionally — so this row is **scope-only**. Mounted inside
 * an agent preset it shadows the deployment persona for that one session,
 * exactly like the per-child persona `arx-subagent` installs; mounted globally
 * it collides with the registry's own registration and fails loud.
 *
 * That constraint is the reason the row exists. An agent preset cannot mount
 * the prompt registry itself, so without a row of its own a preset could
 * change an agent's tools but never its identity.
 * @module @arx-ai/arx-persona
 */
import type { Context } from '@arx-ai/cordis';
import z from '@arx-ai/schemastery';
import { PERSONA_ORDER, PERSONA_SECTION } from '@arx-ai/arx-system-prompt';
export { PERSONA_ORDER, PERSONA_SECTION };
/** Cordis plugin name. */
export declare const name = "persona";
/** The prompt registry this row contributes to. */
export declare const inject: string[];
/** Plugin config: the persona text this composition contributes. */
export interface Config {
    /**
     * Persona prose rendered as the `deployment:persona` section. A template:
     * complete `{{…}}` groups interpolate strictly against registered prompt
     * variables. Empty text drops the section at render, matching the registry.
     */
    text: string;
    /** Make this persona the complete system prompt, suppressing every other section. */
    complete?: boolean;
    /** Suppress dynamic runtime-context snapshots for this persona's agent scope. */
    includeRuntimeContext?: boolean;
}
/** Runtime schema for the persona row. */
export declare const Config: z<Config>;
/**
 * Register the persona section for the mounting context's scope.
 * @param ctx - an agent scope context; an unscoped context collides with the
 * prompt registry's own persona registration and rejects.
 * @param config - the persona text and complete-prompt policy.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map