/**
 * Cordis plugin registering vendor-CLI model routes on the shared `llm`
 * service.
 *
 * @module @arx-ai/arx-llm-agent-cli
 */
import type { Context } from '@arx-ai/cordis';
import { Config } from './config.ts';
export { AgentCliAdapter } from './adapter.ts';
export { Config, DEFAULT_DISPOSE_GRACE_MS, resolveRoutes } from './config.ts';
export type { AgentCliModel, AgentCliProfile, ResolvedRoute } from './config.ts';
export { MCP_SERVER_NAME } from './tools.ts';
export declare const name = "llm-agent-cli";
export declare const inject: string[];
/**
 * Register one route per configured provider.
 *
 * A composition mounts this plugin unconditionally; a deployment decides
 * whether it serves anything. With no configured provider the plugin holds no
 * route, so the model picker gains nothing and no request can reach a CLI that
 * the host may not even have logged in.
 * @param ctx - plugin context carrying the llm and subprocess services.
 * @param config - configured provider routes.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map