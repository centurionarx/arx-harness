/**
 * Translation from the vendor SDK's message stream to the harness chunk
 * protocol.
 *
 * @module @arx-ai/arx-llm-agent-cli/stream
 */
import type { SDKMessage } from '@anthropic-ai/claude-agent-sdk';
import { type StreamChunk } from '@arx-ai/arx-llm';
/**
 * Convert the SDK message stream into harness chunks.
 *
 * One `stream()` call is one assistant turn, and the translation ends the
 * moment that turn does. The CLI's own turn cap cannot express this: reaching
 * it makes the SDK throw an error result rather than finish, so the cap would
 * turn every ordinary tool-calling turn into a failure.
 *
 * The iterator is pulled rather than iterated with `for await`, because the
 * conversation outlives this turn: leaving a `for await` calls `return()` on
 * the vendor run, ending the very conversation the next turn continues.
 *
 * The finish reason comes from the emitted content: a turn that asked for a
 * tool reports `tool-calls`, whatever the vendor would have said about it.
 * @param messages - the live vendor message iterator, positioned at this turn.
 * @returns the harness chunk stream for that turn.
 */
export declare function translate(messages: AsyncIterator<SDKMessage>): AsyncIterable<StreamChunk>;
//# sourceMappingURL=stream.d.ts.map