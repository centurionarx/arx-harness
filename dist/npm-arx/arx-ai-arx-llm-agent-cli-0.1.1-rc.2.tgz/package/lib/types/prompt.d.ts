/**
 * Rendering of harness messages into the one user message that opens a vendor
 * run.
 *
 * @module @arx-ai/arx-llm-agent-cli/prompt
 */
import type { AttachmentId, ImageAttachmentRef, RequestImageAttachment } from '@arx-ai/arx-attachment';
import { type Message } from '@arx-ai/arx-llm';
/** Content blocks the vendor CLI accepts on a user message. */
export type VendorContent = {
    type: 'text';
    text: string;
} | {
    type: 'image';
    source: {
        type: 'base64';
        media_type: string;
        data: string;
    };
};
/**
 * Every image attachment one request references, in first-appearance order.
 * @param messages - the request's complete assembled history.
 * @returns the distinct references, keyed by attachment id.
 */
export declare function collectImageRefs(messages: readonly Message[]): ReadonlyMap<AttachmentId, ImageAttachmentRef>;
/**
 * Render a whole transcript as the content of the one user message that opens
 * a vendor run.
 *
 * Every call opens its own run, and a run accepts no assistant turns, so prior
 * turns are stated as labelled text. Images stay images: they ride as their own
 * blocks, in the position their text occupied, so the model reads them where
 * they were attached rather than as a footnote.
 * @param messages - the request's complete assembled history.
 * @param images - request versions for every referenced attachment, keyed by attachment id.
 * @returns the ordered content blocks describing the conversation so far.
 */
export declare function renderTranscript(messages: readonly Message[], images?: ReadonlyMap<AttachmentId, RequestImageAttachment>): readonly VendorContent[];
//# sourceMappingURL=prompt.d.ts.map