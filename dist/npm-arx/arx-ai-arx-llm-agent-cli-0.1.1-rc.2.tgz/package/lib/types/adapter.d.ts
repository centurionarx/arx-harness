/**
 * The `LlmAdapter` that drives a subscription-authenticated vendor CLI as an
 * ordinary model route.
 *
 * @module @arx-ai/arx-llm-agent-cli/adapter
 */
import { LlmAdapter, type GenerateOptions, type LlmModelInfo, type LlmProviderInfo, type LlmResolvedModelInfo, type StreamChunk } from '@arx-ai/arx-llm';
import type { AttachmentStore } from '@arx-ai/arx-attachment';
import type { SubprocessHandle, SubprocessSpawnSpec } from '@arx-ai/arx-subprocess';
import type { ResolvedRoute } from './config.ts';
/** What the adapter needs from the composition it runs in. */
export interface AgentCliAdapterSpec {
    /** Routes this adapter serves, as configuration resolved them. */
    readonly routes: () => ReadonlyMap<string, ResolvedRoute>;
    /** Process owner for the CLI the SDK spawns. */
    readonly spawn: (spec: SubprocessSpawnSpec) => SubprocessHandle;
    /** Workspace the CLI runs in. */
    readonly cwd: () => string;
    /** Durable attachment bytes, absent in a composition that mounts no store. */
    readonly attachments: () => AttachmentStore | undefined;
}
/**
 * Drive a vendor CLI as a model route.
 *
 * The CLI is an agent with a tool loop of its own. Three settings turn it into
 * one model call: the harness system prompt replaces its own, its built-in
 * tools are refused by name while the harness tools arrive over an in-process
 * MCP server, and every permission request is denied so no tool it asks for
 * can run outside the harness. The turn cap stops it after one assistant turn,
 * which is exactly `stream()`'s contract.
 */
export declare class AgentCliAdapter extends LlmAdapter {
    private readonly spec;
    constructor(spec: AgentCliAdapterSpec);
    /** Resolve one configured route or fail naming it. */
    private route;
    /**
     * Describe one configured route.
     * @param provider - a route this adapter registered.
     * @returns display metadata for that route.
     */
    providerInfo(provider: string): LlmProviderInfo;
    /**
     * List the models configuration gave this route.
     * @param provider - a route this adapter registered.
     * @returns the configured models in configuration order.
     */
    listModels(provider: string): Promise<readonly LlmModelInfo[]>;
    /**
     * Resolve one exact model's capacity and call defaults.
     * @param provider - a route this adapter registered.
     * @param model - exact model id.
     * @returns identity plus the configured context capacity.
     */
    resolveModel(provider: string, model: string): Promise<LlmResolvedModelInfo>;
    /**
     * Build the fixed SDK options that make one CLI run behave as one model call.
     * @param options - the assembled harness request.
     * @param route - the resolved route serving it.
     * @param capture - receives the managed child the SDK spawns.
     * @returns options for one `query()` call.
     */
    private queryOptions;
    /**
     * Stream one model call through the vendor CLI.
     *
     * Each call is one vendor run, started and released here. A run cannot be
     * carried across calls: the CLI resolves a tool call itself the moment
     * permission is refused, so a result the harness produces afterwards would
     * arrive for a call that run already closed.
     * @param options - the fully assembled harness request.
     * @returns the harness chunk stream for that call.
     */
    /**
     * Resolve every image one request references into provider-ready bytes.
     * @param options - the assembled harness request.
     * @param signal - cancellation for the reads.
     * @returns request versions keyed by attachment id.
     */
    private requestImages;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
}
//# sourceMappingURL=adapter.d.ts.map