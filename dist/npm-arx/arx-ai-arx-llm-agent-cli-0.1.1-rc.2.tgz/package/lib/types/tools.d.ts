/**
 * Harness tool schemas presented to the vendor CLI as one in-process MCP
 * server, and the name mapping that presentation forces.
 *
 * @module @arx-ai/arx-llm-agent-cli/tools
 */
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import type { ToolSchema } from '@arx-ai/arx-llm';
/**
 * Server name the CLI uses to namespace these tools. It is part of every name
 * the model sees, so changing it changes model-visible text.
 */
export declare const MCP_SERVER_NAME = "arx";
/**
 * Render one harness tool name as the CLI presents it to the model.
 * @param name - tool name as the harness registered it.
 * @returns the namespaced name the model will emit in a tool call.
 */
export declare function toolAlias(name: string): string;
/**
 * Recover the harness tool name from what the model emitted. A name without
 * the prefix is returned unchanged: the CLI's own built-ins are refused by
 * name elsewhere, and silently rewriting an unexpected name would hide which
 * tool the model actually asked for.
 * @param alias - tool name as it arrived from the model.
 * @returns the harness tool name.
 */
export declare function harnessToolName(alias: string): string;
/**
 * Serve the request's tool schemas over MCP, verbatim.
 *
 * The schemas are JSON Schema because that is what the model sees everywhere
 * else in this harness. The SDK's own `tool()` helper takes a Zod shape and
 * would force a lossy translation of every tool the harness registers, so
 * this answers `tools/list` from the low-level server instead.
 * @param tools - tool schemas assembled for this request.
 * @returns an MCP server instance the SDK can mount in-process.
 */
export declare function createToolServer(tools: readonly ToolSchema[]): McpServer;
//# sourceMappingURL=tools.d.ts.map