import type { IconProps } from './icons/props.ts';
/**
 * Render the brand wordmark.
 * @param props.size - height in px (default 34; width follows the artwork).
 * @param props.className - extra class for layout placement.
 * @returns the wordmark svg (aria-hidden decorative brand art).
 */
export declare function BrandWordmark({ size, className }: IconProps): import("react").JSX.Element;
//# sourceMappingURL=BrandWordmark.d.ts.map