import type { IconProps } from './icons/props.ts';
/**
 * Render the brand mark.
 * @param props.size - width in px (default 24; height keeps the 253:136 ratio).
 * @param props.className - extra class for layout placement.
 * @returns the mark element (aria-hidden; pair with the wordmark for accessibility).
 */
export declare function BrandMark({ size, className }: IconProps): import("react").JSX.Element;
//# sourceMappingURL=BrandMark.d.ts.map