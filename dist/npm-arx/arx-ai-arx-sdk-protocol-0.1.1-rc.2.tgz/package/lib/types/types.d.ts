/**
 * Named wire types for the arx Harness SDK runtime protocol: the three
 * request/result pairs and the four server-to-client notification payloads
 * exchanged over the newline-delimited JSON-RPC stdio transport. The server
 * plugin (`@arx-ai/arx-sdk-jsonrpc-server`) and SDK clients share these shapes;
 * `serverInfo.name` stays the wire-stable `arx-harness-sdk-runtime`.
 *
 * @module @arx-ai/arx-sdk-protocol/types
 */
import type { ContentBlock } from '@arx-ai/arx-llm';
import type { SessionEvent } from '@arx-ai/arx-session';
import type { SubagentStopReason } from '@arx-ai/arx-subagent';
/** Parameters for the process-wide SDK handshake. */
export interface InitializeParams {
    /** Working directory recorded on every SDK-created session's header. */
    cwd: string;
    /** Provider route every SDK-created agent runs on. */
    provider: string;
    /** Model name every SDK-created agent runs on (the server may mount a fallback adapter; see `HarnessSdkJsonRpcServer.initialize`). */
    model: string;
    /** Optional positive output-token cap inherited by SDK-created agents and their in-process descendants. */
    maxTokens?: number;
}
/** Wire-stable server identity returned by initialization. */
export interface InitializeResult {
    /** Wire-stable server identity (`arx-harness-sdk-runtime`) and version. */
    serverInfo: {
        name: string;
        version: string;
    };
}
/** One user turn on one SDK session. */
export interface SessionPromptParams {
    /** The SDK-side session id; an unknown id lazily creates the agent+session pair. */
    sessionId: string;
    /** The prompt content blocks, sent verbatim as the user message. */
    contentBlocks: ContentBlock[];
}
/** Durable enqueue receipt for one prompt. */
export interface SessionPromptResult {
    /** Identity of the queued user message. */
    messageId: string;
}
/** Deployment-mapped SDK outcome: `ok` for an accepted result, `error` otherwise. */
export type SdkRunStatus = 'ok' | 'error';
/** `session.event` payload: one session-log event, streamed as it is recorded. */
export interface SessionEventNotification {
    /** Session the event belongs to (every session in the runtime, not only SDK-created ones). */
    sessionId: string;
    /** The full session-log event envelope. */
    event: SessionEvent;
}
/** Whole-agent lifecycle state for one session. */
export interface SessionStatusNotification {
    /** Session whose live agent changed status. */
    sessionId: string;
    /** The whole-agent state after the transition. */
    status: 'idle' | 'running';
}
/** `subagent.started` payload: an in-runtime child session was created. */
export interface SubagentStartedNotification {
    /** The delegating session. */
    parentSessionId: string;
    /** The new child session. */
    childSessionId: string;
}
/** `subagent.finished` payload: an in-process subagent run ended (remote runs are not reported). */
export interface SubagentFinishedNotification {
    /** Subagent provider name that ran the child. */
    provider: string;
    /** The child agent's id (equals {@link childSessionId} for local runs). */
    agentId: string;
    /** The delegating session. */
    parentSessionId: string;
    /** The child session. */
    childSessionId: string;
    /** Deployment-mapped run outcome. */
    status: SdkRunStatus;
    /** The provider-reported stop reason. */
    stopReason: SubagentStopReason;
    /** The child's selected assistant output; absent when the child produced none. */
    lastAssistantMessage?: ContentBlock[];
}
/** Server-to-client notifications by JSON-RPC method name. */
export interface HarnessSdkNotificationMap {
    'session.event': SessionEventNotification;
    'session.status': SessionStatusNotification;
    'subagent.started': SubagentStartedNotification;
    'subagent.finished': SubagentFinishedNotification;
}
/** Client-to-server request methods with their param and result shapes. */
export interface HarnessSdkRequestMap {
    'initialize': {
        params: InitializeParams;
        result: InitializeResult;
    };
    'session/prompt': {
        params: SessionPromptParams;
        result: SessionPromptResult;
    };
    'shutdown': {
        params: undefined;
        result: Record<string, never>;
    };
}
//# sourceMappingURL=types.d.ts.map