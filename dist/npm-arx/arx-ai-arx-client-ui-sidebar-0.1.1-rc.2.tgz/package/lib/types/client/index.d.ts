/** Registers the sidebar shell into the layout-owned slot. */
import type { ClientContext } from '@arx-ai/arx-client-runtime/client';
import { type SidebarKey } from './locales.ts';
export type { SidebarBrandMarkOwnerProps, SidebarBrandNameOwnerProps, SidebarFooterActionOwnerProps, SidebarRootComponentProps, SidebarRootInjected, SidebarSectionOwnerProps, SidebarSettingsOwnerProps, } from './contract/slots.ts';
export type { SidebarKey } from './locales.ts';
declare module '@arx-ai/arx-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Sidebar shell controls copy. */
        sidebar: SidebarKey;
    }
}
/** Services required by the sidebar plugin. */
export declare const inject: string[];
/** Registers the sidebar shell and its service callbacks.
 * @param ctx - Client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map