#!/usr/bin/env node
/**
 * Generic JSON-RPC agent bin. External configurations own their bare plugin
 * packages; the packaged runtime uses `packaged-bin.ts` instead.
 *
 * @module @arx-ai/arx-sdk-jsonrpc-demo/bin
 */
export {};
//# sourceMappingURL=bin.d.ts.map