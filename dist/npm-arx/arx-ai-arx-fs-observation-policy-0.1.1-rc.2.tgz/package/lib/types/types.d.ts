/**
 * Vocabulary for the fs-observation-policy plugin: the minimal execution-context
 * fields used to derive an observed-state owner by narrowing the opaque `object`
 * actor the `fs/*` events carry.
 *
 * The provider vocabulary (`FsTarget`, `FsVersion`, write/edit request types) is
 * re-used from `@arx-ai/arx-fs`; this package owns only the observed-state
 * owner structure on top of it.
 *
 * @module @arx-ai/arx-fs-observation-policy/types
 */
/**
 * Minimal structural view of a tool execution the policy plugin needs to derive
 * an observed-state owner. `@arx-ai/arx-tools`' `ToolExecution` contains
 * these fields, so the tool passes its `exec` straight through as the opaque
 * `object` actor on the `fs/*` events; this plugin narrows that actor to
 * `FsObservationActor` without importing `arx-tools`, `arx-agent`, or `arx-session`.
 *
 * The owner is `agent.session` when present. It is treated as an opaque object
 * identity (a `WeakMap` key); this package never reads any of its fields.
 */
export interface FsObservationActor {
    /** The agent on whose behalf the call runs, when there is one. */
    agent?: {
        /** The session that owns observed-file state, used as an opaque key. */
        session?: object;
    };
}
//# sourceMappingURL=types.d.ts.map