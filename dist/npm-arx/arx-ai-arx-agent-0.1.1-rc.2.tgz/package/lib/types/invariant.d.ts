/** Package-owned agent lifecycle invariants. @module @arx-ai/arx-agent/invariant */
import type { Context } from '@arx-ai/cordis';
/** Cordis companion plugin name. */
export declare const name = "agent-invariant";
/** Services required before the companion can register. */
export declare const inject: string[];
/**
 * Register the agent invariant companion.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns the installed registration's disposer after setup succeeds.
 */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map