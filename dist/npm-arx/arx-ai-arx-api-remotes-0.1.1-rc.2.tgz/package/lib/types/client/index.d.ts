/** Platform-neutral assembly of generated Host Remote contributions. */
import type { Context } from '@arx-ai/cordis';
import type { TypertClientRemote } from '@arx-ai/arx-typert-protocol';
export type { TypertClientRemote as ClientRemote } from '@arx-ai/arx-typert-protocol';
export type { PluginInventorySnapshot } from '@arx-ai/arx-host-plugin-inventory/types';
export type {} from '@arx-ai/arx-commands/remote';
export type {} from '@arx-ai/arx-file-reference/remote';
export type {} from '@arx-ai/arx-goal/remote';
export type {} from '@arx-ai/arx-host-plugin-inventory/remote';
export type {} from '@arx-ai/arx-message-feedback/remote';
export type {} from '@arx-ai/arx-session-reference/remote';
export type { ApiRemoteForwardedEvent } from '../types.ts';
export type {} from '@arx-ai/arx-commands/types';
export type {} from '@arx-ai/arx-cordis-host-runner/types';
export type {} from '@arx-ai/arx-credentials/types';
export type {} from '@arx-ai/arx-llm/types';
export type {} from '@arx-ai/arx-agent-presets/types';
export type {} from '@arx-ai/arx-settings/types';
/**
 * The carrier's Client-facing types, re-exported so a business package names one
 * assembly package instead of both this facade and the Connection plugin. Type-only:
 * the carrier's runtime values stay behind their own module edge.
 */
export type { ClientResponse, ConfigurableProviderView, ConnectionHandle, ConnectionSinks, ContentBlock, CredentialView, DirectoryListing, DiscoveredModelView, HistoryEntry, HostFrame, IApiClient, MessageId, ModelCatalogFailure, ModelProviderGroup, ModelReasoningEffort, ModelSelection, MuxFrame, PromptContentPart, QuestionResponsePayload, QueueAction, RpcError, RpcId, RpcReceipt, RpcRequest, RpcResponse, RpcResult, SessionId, SessionModels, SessionSearchItem, SessionSummary, SettingsNamespaceView, SettingsPathOpView, SkillEntry, StreamChunk, SubagentAddress, SubagentCatalog, JobView, ToolCallView, ToolEventView, ToolResultView, WorkspaceId, WorkspaceView, } from '@arx-ai/arx-client-connection/client';
export type {} from '@arx-ai/arx-api-gateway/client';
export type {} from '@arx-ai/arx-cordis-host-runner/remote';
export type { ApprovalRequestId, CordisHalfState, CordisDynamicPackageId, CordisDynamicPluginId, CordisDynamicPluginRunId, CordisDynamicRunMode, CordisInspectMethodManifest, CordisInspectPlatform, CordisInspectProviderManifest, CordisInspectProviderView, CordisInspectQueryRequest, CordisInspectQueryResolution, CordisInspectQueryResolved, CordisInspectRequestId, CordisInspectResolveAck, CordisRunDiagnostic, CordisRunStatus, DynamicCordisClientSource, DynamicCordisHostHalfResult, DynamicCordisInventoryRow, DynamicCordisInvokeResult, DynamicCordisPackage, DynamicCordisRequestResolved, DynamicCordisResolveAck, DynamicCordisRetracted, DynamicCordisRunRequest, DynamicCordisRunResolution, DynamicCordisRunAttempt, DynamicCordisRunResponse, DynamicCordisStopResponse, DynamicCordisUndefineReceipt, RequestRunOutcome, } from '@arx-ai/arx-cordis-host-runner/types';
export type { JsonValue } from '@arx-ai/arx-session/types';
export type { FileReferenceCandidate } from '@arx-ai/arx-file-reference/types';
export type { SessionReferenceMentionCandidate } from '@arx-ai/arx-session-reference/types';
declare module '@arx-ai/cordis' {
    interface Context {
        /** Generated Remote namespaces selected by this Client assembly. */
        remote: TypertClientRemote;
    }
}
/** Required service: the typed Client Remote contribution mount. */
export declare const inject: string[];
/**
 * Mount the Host capabilities explicitly selected for this Client assembly.
 * @param ctx - Client Cordis root carrying the typed API service.
 * @returns disposer after every selected Remote namespace is ready.
 */
export declare function apply(ctx: Context): Promise<() => Promise<void>>;
//# sourceMappingURL=index.d.ts.map