/** Exit-seat dictionaries: the foot row and its confirmation. */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    trigger: string;
    'confirm.title': string;
    'confirm.description': string;
    'confirm.cancel': string;
    'confirm.stop': string;
    close: string;
    stopping: string;
    unavailable: string;
};
/** The exit namespace key union. */
export type ExitKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    trigger: string;
    'confirm.title': string;
    'confirm.description': string;
    'confirm.cancel': string;
    'confirm.stop': string;
    close: string;
    stopping: string;
    unavailable: string;
};
//# sourceMappingURL=locales.d.ts.map