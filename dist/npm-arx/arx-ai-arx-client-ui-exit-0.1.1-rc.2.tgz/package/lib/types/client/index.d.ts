/**
 * Harness exit plugin, browser half: fills the sidebar's `sidebar.exit` seat
 * with the foot row below Settings, and owns the `exit` dictionaries. The
 * shutdown belongs to the launcher — this package only asks for it, over
 * `host.exit`, and reports the one refusal a deployment can answer with.
 * Export discipline: packages/client/AGENTS.md.
 */
import type { ClientContext } from '@arx-ai/arx-client-runtime/client';
import { type ExitKey } from './locales.ts';
export type { ExitRowInjected, ExitRowProps } from './ExitRow.tsx';
export type { ExitKey } from './locales.ts';
declare module '@arx-ai/arx-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Exit row and confirmation copy. */
        exit: ExitKey;
    }
}
/** Required services (cordis fiber inject): slot registry, dictionaries, wire handle. */
export declare const inject: string[];
/**
 * Register the `exit` dictionaries and the exit seat's occupant, the latter
 * once ui-sidebar's declaration is on the ledger.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map