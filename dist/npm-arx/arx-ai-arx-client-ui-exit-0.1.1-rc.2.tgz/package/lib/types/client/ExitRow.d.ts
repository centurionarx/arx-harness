import type { ReactElement } from 'react';
import type { PropsLocale, PropsRuntime } from '@arx-ai/arx-client-ui-slots';
/** Injected face: the wire call the row drives (bound in apply's closure). */
export interface ExitRowInjected {
    /**
     * Ask the Host to stop the harness. Never rejects.
     * @returns false when the deployment refused, which it does when its
     * launcher provided no exit request; true otherwise. The answer arrives
     * before the process goes, because the connection carrying it dies with the
     * server — so a transport failure after the ask reports true as well, being
     * indistinguishable from a shutdown that raced its own response.
     */
    stop: () => Promise<boolean>;
}
/** Full row props: the sidebar column state, the injected call, and locale. */
export type ExitRowProps = PropsRuntime<'sidebar.exit'> & ExitRowInjected & PropsLocale<'exit'>;
/**
 * Render the exit row and its confirmation.
 *
 * The confirmation is not ceremony: the control ends the server that serves
 * the page, so the viewer cannot undo it from the UI it is looking at. A
 * started shutdown never returns to idle — the page it lives on is going.
 * @param props - composed slot props.
 * @returns the foot row, plus the dialog while one is open.
 */
export declare function ExitRow({ wide, stop, t }: ExitRowProps): ReactElement;
//# sourceMappingURL=ExitRow.d.ts.map