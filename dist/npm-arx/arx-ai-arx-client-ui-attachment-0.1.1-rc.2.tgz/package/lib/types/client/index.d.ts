/** Browser attachment plugin: fills conversation's composer and message-image slots. */
import type { ClientContext } from '@arx-ai/arx-client-runtime/client';
/** Slot registry required by this presentation plugin. */
export declare const inject: string[];
/** Register attachment presentation without exporting React components as package values. */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map