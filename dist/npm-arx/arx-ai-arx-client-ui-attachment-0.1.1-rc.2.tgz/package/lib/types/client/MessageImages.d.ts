import type { MessageImagesProps } from '@arx-ai/arx-client-ui-conversation/client';
/** Historical message-image slot entry. */
export declare function MessageImages({ images, loadImage, align, t }: MessageImagesProps): import("react").JSX.Element;
//# sourceMappingURL=MessageImages.d.ts.map