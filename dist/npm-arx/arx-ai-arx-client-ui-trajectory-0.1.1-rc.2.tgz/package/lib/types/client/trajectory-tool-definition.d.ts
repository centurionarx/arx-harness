import type { Context } from '@arx-ai/cordis';
/**
 * Register the Trajectory Tool lifecycle.
 *
 * @param ctx - Plugin context receiving the Definition.
 */
export declare function registerTrajectoryToolDefinition(ctx: Context): void;
//# sourceMappingURL=trajectory-tool-definition.d.ts.map