/**
 * Shared browser platform modules. Seeding, bundling externals, and Vite
 * aliases consume this list so their module identities cannot drift.
 * @module @arx-ai/arx-client-web/src/platform
 */
/** The module specifiers the shell shares into the frozen module table. */
export declare const PLATFORM_MODULES: readonly ["react", "react/jsx-runtime", "react-dom", "react-dom/client", "@arx-ai/cordis", "@arx-ai/arx-client-ui-slots", "@arx-ai/arx-client-ui-primitives"];
/** Client-bundle specifiers whose factories the parser preloads before the shell starts. */
export declare const PRELOADED_CLIENT_EXTERNALS: readonly ["@arx-ai/arx-client-runtime/client"];
/** One platform module specifier (a seed-table key). */
export type PlatformModule = (typeof PLATFORM_MODULES)[number];
//# sourceMappingURL=platform.d.ts.map