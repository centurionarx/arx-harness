/**
 * Package-owned invariant companion for `@arx-ai/arx-commands`:
 * command lifecycle events pair by commandId within one session log.
 * @module @arx-ai/arx-commands/invariant
 */
import type { Context } from '@arx-ai/cordis';
/** Cordis companion plugin name. */
export declare const name = "commands-invariant";
/** Service required before the companion can reserve package ownership. */
export declare const inject: string[];
/**
 * Register this package's invariant companion.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns the installed registration's disposer after setup succeeds.
 */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map