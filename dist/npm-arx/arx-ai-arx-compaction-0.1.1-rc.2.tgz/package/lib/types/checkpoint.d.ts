/**
 * Compaction checkpoint provenance: the correlated source constructor and type
 * every backend uses for its replacement user message, plus the predicate that
 * recognizes persisted checkpoints.
 *
 * The seam itself lives in `@arx-ai/arx-compaction`, which re-exports these
 * contracts; this module is a pure type/value/predicate outlet (no cordis
 * imports, no module augmentation) so client and wire programs can name the
 * checkpoint source without loading the host plugin's Context merges — the
 * `arx-commands/brand` shape.
 *
 * @module @arx-ai/arx-compaction/checkpoint
 */
import type { MessageSource } from '@arx-ai/arx-llm/message';
import type { CommandId } from '@arx-ai/arx-commands/brand';
import type { CompactionId } from './brand.ts';
declare const COMPACT_CHECKPOINT_MARKER: Readonly<{
    readonly kind: "plugin";
    readonly plugin: "compact";
}>;
/** Message provenance carried by a concrete compaction checkpoint. */
export type CompactionCheckpointSource = typeof COMPACT_CHECKPOINT_MARKER & {
    readonly compactionId: CompactionId;
    readonly sourceCommandId?: CommandId;
};
/**
 * Create checkpoint provenance correlated with one compaction transaction.
 * @param compactionId - owning compaction identity.
 * @param sourceCommandId - initiating manual command, when present.
 * @returns immutable checkpoint source.
 */
export declare function compactCheckpointSource(compactionId: CompactionId, sourceCommandId?: CommandId): CompactionCheckpointSource;
/**
 * Test whether a persisted message source identifies a compaction checkpoint.
 * @param source - source restored from a surface user message.
 * @returns whether the source carries the backend-independent checkpoint marker.
 */
export declare function isCompactCheckpointSource(source: MessageSource): boolean;
export {};
//# sourceMappingURL=checkpoint.d.ts.map