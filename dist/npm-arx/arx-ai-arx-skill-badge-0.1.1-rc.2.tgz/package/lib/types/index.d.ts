/**
 * Bundled `arx-badge` skill provider.
 *
 * @module @arx-ai/arx-skill-badge
 */
import type { Context } from '@arx-ai/cordis';
/** Cordis plugin name. */
export declare const name = "skill-badge";
/** Service required by the bundled provider. */
export declare const inject: string[];
/** Register the bundled `arx-badge` provider on `ctx.skills`. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map