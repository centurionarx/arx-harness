import { Group } from '@arx-ai/cordis-plugin-loader';
export default Group;
//# sourceMappingURL=index.d.ts.map